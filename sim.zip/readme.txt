I added sample.css, sample.js and sample.html into each folder. They are sample files, so please remove it.


Usage:

- Download the sim.zip file and extract into your project folder.
- Move html files into /html/ folder, move css files into /css/ folder and move js files into /js/ folder.
- Open "minifier.php" and Minify your files.
- After you Minify it, the result (Minified Js and Css files) will be inside /minify/ folder and the minifed html files will be in your project root folder.